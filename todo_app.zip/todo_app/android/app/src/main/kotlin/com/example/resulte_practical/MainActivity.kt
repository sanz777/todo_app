package com.example.resulte_practical

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
